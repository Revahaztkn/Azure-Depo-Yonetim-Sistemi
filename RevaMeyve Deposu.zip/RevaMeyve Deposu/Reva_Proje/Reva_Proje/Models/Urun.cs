﻿using System.ComponentModel.DataAnnotations;

namespace Reva_Proje.Models
{
    public class Urun
    {
        [Required(ErrorMessage = "Ürün ID zorunludur.")]
        public int Id { get; set; }
        [Required(ErrorMessage = "Ürün adı  zorunludur.")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Stok Rakamı zorunludur.")]
        public int Stok { get; set; }

    }
}