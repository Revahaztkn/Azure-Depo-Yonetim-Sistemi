﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;

namespace Reva_Proje.Models
{
    public class Uygulamadbcontext:DbContext
    { 
        public Uygulamadbcontext(DbContextOptions<Uygulamadbcontext>options): base(options) 
        { }
        public DbSet<Urun> Urunler { get; set; }
    }
}
