﻿using Microsoft.AspNetCore.Mvc;
using Reva_Proje.Models;


namespace Reva_Proje.Controllers
{
    public class UrunlerimizController : Controller
    {

        public IActionResult Index()
        {
            List<Urun> objUrunList = _uygulamadbcontext.Urunler.ToList();
            return View(objUrunList);
        }
        private readonly Uygulamadbcontext _uygulamadbcontext;

        public UrunlerimizController(Uygulamadbcontext context)
        {
            _uygulamadbcontext = context;
        }

        public IActionResult Ekle() 
        {
            return View();
        }

        public IActionResult Urunler()
        {
            List<Urun> objUrunList = _uygulamadbcontext.Urunler.ToList();
            return View("~/Views/Home/Urunler.cshtml",objUrunList);
        }

        [HttpPost]
        public IActionResult Ekle(Urun urun)
        {
            if (ModelState.IsValid)
            {
                _uygulamadbcontext.Urunler.Add(urun);
                _uygulamadbcontext.SaveChanges();
                return RedirectToAction("Index","Urunlerimiz");
            }
            return View();
        }

        public IActionResult Guncelle(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }
            Urun? REVA_PROJE = _uygulamadbcontext.Urunler.Find(id);
            if (REVA_PROJE == null)
            {
                return NotFound();
            }
            return View(REVA_PROJE);
        }

        [HttpPost]
        public IActionResult Guncelle(Urun urun)
        {
            if (ModelState.IsValid)
            {
                _uygulamadbcontext.Urunler.Update(urun);
                _uygulamadbcontext.SaveChanges();
                return RedirectToAction("Index", "Urunlerimiz");
            }
            return View(urun);
        }


        public IActionResult Sil(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }
            Urun? REVA_PROJE = _uygulamadbcontext.Urunler.Find(id);
            if (REVA_PROJE == null)
            {
                return NotFound();
            }
            return View(REVA_PROJE);
        }



        [HttpPost]
        public IActionResult Sil(Urun urun)
        {

            if (ModelState.IsValid)
            {
                _uygulamadbcontext.Urunler.Remove(urun);
                _uygulamadbcontext.SaveChanges();
                return RedirectToAction("Index", "Urunlerimiz");
            }
            return View();
        }

    }
}